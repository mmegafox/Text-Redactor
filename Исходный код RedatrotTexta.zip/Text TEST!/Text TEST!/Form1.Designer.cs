﻿namespace Text_TEST_
{
    partial class Grishin
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Grishin));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.загрузитьФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вырезатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.форматToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выделениеТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.форматТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.жирныйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.курсивToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.подчеркиваниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вернутьТекстВНормуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьВыделенныйТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.яПомогуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.чтоЯТакоеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.посчитаемToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.количествоБуквToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.количествоСловToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.количествоСпецСимволовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.количествоСтрокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.редактироватьToolStripMenuItem,
            this.форматToolStripMenuItem,
            this.помощьToolStripMenuItem,
            this.посчитаемToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(563, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.загрузитьФайлToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // создатьToolStripMenuItem
            // 
            this.создатьToolStripMenuItem.Name = "создатьToolStripMenuItem";
            this.создатьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F1)));
            this.создатьToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.создатьToolStripMenuItem.Text = "Создать";
            this.создатьToolStripMenuItem.Click += new System.EventHandler(this.создатьToolStripMenuItem_Click);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.сохранитьToolStripMenuItem_Click);
            // 
            // загрузитьФайлToolStripMenuItem
            // 
            this.загрузитьФайлToolStripMenuItem.Name = "загрузитьФайлToolStripMenuItem";
            this.загрузитьФайлToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.загрузитьФайлToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.загрузитьФайлToolStripMenuItem.Text = "Загрузить файл";
            this.загрузитьФайлToolStripMenuItem.Click += new System.EventHandler(this.загрузитьФайлToolStripMenuItem_Click);
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.копироватьToolStripMenuItem,
            this.вставитьToolStripMenuItem,
            this.вырезатьToolStripMenuItem,
            this.удалитьToolStripMenuItem});
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(99, 20);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            // 
            // копироватьToolStripMenuItem
            // 
            this.копироватьToolStripMenuItem.Name = "копироватьToolStripMenuItem";
            this.копироватьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.копироватьToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.копироватьToolStripMenuItem.Text = "Копировать";
            this.копироватьToolStripMenuItem.Click += new System.EventHandler(this.копироватьToolStripMenuItem_Click);
            // 
            // вставитьToolStripMenuItem
            // 
            this.вставитьToolStripMenuItem.Name = "вставитьToolStripMenuItem";
            this.вставитьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.вставитьToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.вставитьToolStripMenuItem.Text = "Вставить";
            this.вставитьToolStripMenuItem.Click += new System.EventHandler(this.вставитьToolStripMenuItem_Click);
            // 
            // вырезатьToolStripMenuItem
            // 
            this.вырезатьToolStripMenuItem.Name = "вырезатьToolStripMenuItem";
            this.вырезатьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.вырезатьToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.вырезатьToolStripMenuItem.Text = "Вырезать";
            this.вырезатьToolStripMenuItem.Click += new System.EventHandler(this.вырезатьToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // форматToolStripMenuItem
            // 
            this.форматToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выделениеТекстаToolStripMenuItem,
            this.форматТекстаToolStripMenuItem,
            this.изменитьВыделенныйТекстToolStripMenuItem});
            this.форматToolStripMenuItem.Name = "форматToolStripMenuItem";
            this.форматToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.форматToolStripMenuItem.Text = "Формат";
            // 
            // выделениеТекстаToolStripMenuItem
            // 
            this.выделениеТекстаToolStripMenuItem.Name = "выделениеТекстаToolStripMenuItem";
            this.выделениеТекстаToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.выделениеТекстаToolStripMenuItem.Text = "Выделение текста";
            this.выделениеТекстаToolStripMenuItem.Click += new System.EventHandler(this.выделениеТекстаToolStripMenuItem_Click);
            // 
            // форматТекстаToolStripMenuItem
            // 
            this.форматТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.жирныйToolStripMenuItem,
            this.курсивToolStripMenuItem,
            this.подчеркиваниеToolStripMenuItem,
            this.вернутьТекстВНормуToolStripMenuItem});
            this.форматТекстаToolStripMenuItem.Name = "форматТекстаToolStripMenuItem";
            this.форматТекстаToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.форматТекстаToolStripMenuItem.Text = "Формат текста";
            // 
            // жирныйToolStripMenuItem
            // 
            this.жирныйToolStripMenuItem.Name = "жирныйToolStripMenuItem";
            this.жирныйToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.жирныйToolStripMenuItem.Text = "Жирный";
            this.жирныйToolStripMenuItem.Click += new System.EventHandler(this.жирныйToolStripMenuItem_Click_1);
            // 
            // курсивToolStripMenuItem
            // 
            this.курсивToolStripMenuItem.Name = "курсивToolStripMenuItem";
            this.курсивToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.курсивToolStripMenuItem.Text = "Курсив";
            this.курсивToolStripMenuItem.Click += new System.EventHandler(this.курсивToolStripMenuItem_Click);
            // 
            // подчеркиваниеToolStripMenuItem
            // 
            this.подчеркиваниеToolStripMenuItem.Name = "подчеркиваниеToolStripMenuItem";
            this.подчеркиваниеToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.подчеркиваниеToolStripMenuItem.Text = "Подчеркивание";
            this.подчеркиваниеToolStripMenuItem.Click += new System.EventHandler(this.подчеркиваниеToolStripMenuItem_Click);
            // 
            // вернутьТекстВНормуToolStripMenuItem
            // 
            this.вернутьТекстВНормуToolStripMenuItem.Name = "вернутьТекстВНормуToolStripMenuItem";
            this.вернутьТекстВНормуToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.вернутьТекстВНормуToolStripMenuItem.Text = "Вернуть текст в норму";
            this.вернутьТекстВНормуToolStripMenuItem.Click += new System.EventHandler(this.вернутьТекстВНормуToolStripMenuItem_Click);
            // 
            // изменитьВыделенныйТекстToolStripMenuItem
            // 
            this.изменитьВыделенныйТекстToolStripMenuItem.Name = "изменитьВыделенныйТекстToolStripMenuItem";
            this.изменитьВыделенныйТекстToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.изменитьВыделенныйТекстToolStripMenuItem.Text = "Изменить выделенный текст";
            this.изменитьВыделенныйТекстToolStripMenuItem.Click += new System.EventHandler(this.изменитьВыделенныйТекстToolStripMenuItem_Click);
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.яПомогуToolStripMenuItem,
            this.чтоЯТакоеToolStripMenuItem});
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.помощьToolStripMenuItem.Text = "Помощь";
            // 
            // яПомогуToolStripMenuItem
            // 
            this.яПомогуToolStripMenuItem.Name = "яПомогуToolStripMenuItem";
            this.яПомогуToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.P)));
            this.яПомогуToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.яПомогуToolStripMenuItem.Text = "Я помогу";
            this.яПомогуToolStripMenuItem.Click += new System.EventHandler(this.яПомогуToolStripMenuItem_Click);
            // 
            // чтоЯТакоеToolStripMenuItem
            // 
            this.чтоЯТакоеToolStripMenuItem.Name = "чтоЯТакоеToolStripMenuItem";
            this.чтоЯТакоеToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.чтоЯТакоеToolStripMenuItem.Text = "Что я такое?";
            this.чтоЯТакоеToolStripMenuItem.Click += new System.EventHandler(this.чтоЯТакоеToolStripMenuItem_Click);
            // 
            // посчитаемToolStripMenuItem
            // 
            this.посчитаемToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.количествоБуквToolStripMenuItem,
            this.количествоСловToolStripMenuItem,
            this.количествоСпецСимволовToolStripMenuItem,
            this.количествоСтрокToolStripMenuItem});
            this.посчитаемToolStripMenuItem.Name = "посчитаемToolStripMenuItem";
            this.посчитаемToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.посчитаемToolStripMenuItem.Text = "Посчитаем";
            // 
            // количествоБуквToolStripMenuItem
            // 
            this.количествоБуквToolStripMenuItem.Name = "количествоБуквToolStripMenuItem";
            this.количествоБуквToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.количествоБуквToolStripMenuItem.Text = "Количество букв";
            this.количествоБуквToolStripMenuItem.Click += new System.EventHandler(this.количествоБуквToolStripMenuItem_Click);
            // 
            // количествоСловToolStripMenuItem
            // 
            this.количествоСловToolStripMenuItem.Name = "количествоСловToolStripMenuItem";
            this.количествоСловToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.количествоСловToolStripMenuItem.Text = "Количество слов";
            this.количествоСловToolStripMenuItem.Click += new System.EventHandler(this.количествоСловToolStripMenuItem_Click);
            // 
            // количествоСпецСимволовToolStripMenuItem
            // 
            this.количествоСпецСимволовToolStripMenuItem.Name = "количествоСпецСимволовToolStripMenuItem";
            this.количествоСпецСимволовToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.количествоСпецСимволовToolStripMenuItem.Text = "Количество символов";
            this.количествоСпецСимволовToolStripMenuItem.Click += new System.EventHandler(this.количествоСпецСимволовToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(563, 391);
            this.panel1.TabIndex = 1;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(563, 391);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // количествоСтрокToolStripMenuItem
            // 
            this.количествоСтрокToolStripMenuItem.Name = "количествоСтрокToolStripMenuItem";
            this.количествоСтрокToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.количествоСтрокToolStripMenuItem.Text = "Количество строк";
            this.количествоСтрокToolStripMenuItem.Click += new System.EventHandler(this.количествоСтрокToolStripMenuItem_Click);
            // 
            // Grishin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 415);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Grishin";
            this.Text = "Grishin DKIP-402";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem загрузитьФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форматToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripMenuItem копироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вставитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вырезатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выделениеТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форматТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem яПомогуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem жирныйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem курсивToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem подчеркиваниеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вернутьТекстВНормуToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem изменитьВыделенныйТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem чтоЯТакоеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem посчитаемToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem количествоБуквToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem количествоСловToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem количествоСпецСимволовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem количествоСтрокToolStripMenuItem;
    }
}

