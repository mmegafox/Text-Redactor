﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Text_TEST_
{
    public partial class Grishin : Form
    {
        public Grishin()
        {
            InitializeComponent();
        }
private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                }
            }
            catch (Exception osh)
            {
                MessageBox.Show("Ошибка сохранения файла: " + osh.Message + " !");
            }

        }

        private void загрузитьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                }
            }
            catch (Exception osh)
            {
                MessageBox.Show("Ошибка чтения файла: " + osh.Message + " !");
            }

            
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void яПомогуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Тебе никто не поможет!");
        }

        private void жирныйToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
                richTextBox1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold);
        }

        private void выделениеТекстаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = colorDialog1.Color;
            }
        }

        private void курсивToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Italic);
        }

        private void подчеркиваниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline);
        }

        private void вернутьТекстВНормуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular);
        }

        private void изменитьВыделенныйТекстToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont = fontDialog1.Font;
            }
        }

        private void чтоЯТакоеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new GrishinMaxim();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void количествоБуквToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string n = richTextBox1.Text;
            int c = n.Count(char.IsLetter);
            MessageBox.Show("В данном тексте найдено: " + c.ToString().Trim(), "Поиск букв", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void количествоСловToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nw = richTextBox1.Text;
            int cl = nw.Split(new char[] {' ', '\r', '\n'}, StringSplitOptions.RemoveEmptyEntries).Length;
            MessageBox.Show("В данном тексте найдено: " + cl.ToString().Trim(), "Поиск слов", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void количествоСпецСимволовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nh = richTextBox1.Text;
            int cg = nh.Length;
            MessageBox.Show("В данном тексте найдено: " + cg.ToString().Trim(), "Поиск символов", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void количествоСтрокToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nr = richTextBox1.Text;
            int ck = nr.Split(new char[] {'\n'}, StringSplitOptions.RemoveEmptyEntries).Length;
            MessageBox.Show("В данном тексте найдено: " + ck.ToString().Trim(), "Поиск строк", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
